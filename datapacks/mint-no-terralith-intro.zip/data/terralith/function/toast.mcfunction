# Mint: privetstvie Terralith v chate otklyucheno.
# Pustaya funkciya perekryvaet terralith:toast iz moda.
